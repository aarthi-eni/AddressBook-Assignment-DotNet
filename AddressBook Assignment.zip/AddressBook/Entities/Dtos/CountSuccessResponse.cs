namespace Entities.Dtos
{
    public class CountSuccessResponse
    {
        ///<summary>
        /// count of addressbook 
        ///</summary>
        public int count { get; set; }
    }
}